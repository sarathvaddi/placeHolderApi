package com.example.usbank.model


import java.io.Serializable


data class AlbumsModel (
    var userId: String? = null,
    var id: String? = null,
    var title: String? = null
):Serializable

