package com.example.usbank

interface ItemClickListener {

    fun  onItemClick(position: Int, id: String?)
}